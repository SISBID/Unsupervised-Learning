##Packages needed for Unsupervised Module

# Install Pacakges for PCA Lab 

install.packages("ggplot2")
install.packages("umap")
install.packages("Rtsne")
install.packages("fastICA")
install.packages("ISLR")
install.packages("GGally")
install.packages("NMF")



# Install Packages for Clustering Lab

install.packages("animation")
install.packages("cvxclustr")
install.packages("cvxbiclustr")
install.packages("sigclust")


# Install Packages for Testing and Graphical Model Lab

install.packages("igraph")
install.packages("XMRF")
install.packages("huge")
install.packages("glasso")
install.packages("WGCNA")
install.packages("glmnet")


# Install Package for Final Lab

BiocManager::install("ConsensusClusterPlus")

